IMPSO Easy Demo

HOW TO RUN:
1. Extract IMPSO_Easy_Demo.zip to a folder.
2. Double-click index.html.
3. It opens in Chrome/Edge. No Java or VS Code setup is needed for this demo.
4. Change number of tasks / swarm / iterations, click Run demo simulation.
5. Click Export results as CSV to save a CSV.

IMPORTANT:
This is a browser-based educational prototype using a simplified discrete neighborhood-search approximation, not the canonical IMPSO algorithm and not CloudSim output. Do not submit its metrics as validated results. Next phase is the actual Java + CloudSim 3.0 implementation.
